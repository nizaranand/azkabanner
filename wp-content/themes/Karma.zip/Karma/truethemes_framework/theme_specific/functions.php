<?php
/*
* Karma Theme specific functions
* Put all functions unique to karma theme here.
* Do not put general functions here.
*/





?>